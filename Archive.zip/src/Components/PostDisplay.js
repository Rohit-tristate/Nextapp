import { Paper } from "@mui/material";
import axios from "axios";
import { Suspense, useEffect, useState } from "react";
import PostCard from "./PostCard";
import Variants from "./Skeleton";
import Search from "./Search";

export default async function PostDisplay(props) {
  const data = await getdata();

  if (data === null) return <p>Something went wrong</p>;

  return (
    <div className="bg-white  mt-10">
      <Suspense fallback={<p>fetching data....</p>}>
        <Search arr={data} />
      </Suspense>
    </div>
  );
}

export async function getdata() {
  try {
    const res = await axios("http://localhost:3000/api/Getpost");

    return res.data.message;
  } catch (error) {
    console.log(error);
    return null;
  }
}
