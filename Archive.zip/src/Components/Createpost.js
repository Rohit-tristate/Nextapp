"use client";

import { Paper } from "@mui/material";
import axios from "axios";
import { useFormik } from "formik";
import { useRouter } from "next/navigation";
import { Suspense, useEffect, useState } from "react";
import { toast } from "react-toastify";
import DeleteIcon from '@mui/icons-material/Delete';
import * as Yup from "yup";
import { useUser } from "@/Components/Context";
export default function Updatepost(props) {
  const router=useRouter();
  const userLogin=useUser();
  const [initialdata,setInitialData]=useState({
    post:props.post,
    title:props.title,
    user:props.user,
    tag:props.tag,
  });

  console.log("update",props.arr)

  if(userLogin.user===null)
    router.push("/")

  useEffect(()=>{
    getUserById()
  },[])

  const getUserById=async ()=>{
  
    const res=await axios.post(`http://localhost:3000/api/Getpost/post`,{id:params.id})
    console.log(res)
     const obj={
      post:res.data.message.post,
      title:res.data.message.title,
      user:res.data.message.user,
      tag:res.data.message.tag

     }
    setInitialData(obj)
  }

  const deletepost=async()=>{

    try{

      if(window.confirm("do you want to delete this post"))
        {
         const res=await axios.delete(`http://localhost:3000/api/deletepost?id=${params.id}`)

          toast.success("post is delete sucessfully")
          router.push("/")
        }

    }catch(error){
      console.log(error)
      return toast.error("unable to delete post")
    }

    
  }


  const postSchema = Yup.object().shape({
    post: Yup.string()
      .min(100, "please enter atleast 100 character !")
      .max(300, "Maxium 300  character is allow only!")
      .required("Required"),
    tag: Yup.string()
      .min(2, "Too Short!")
      .max(50, "Too Long!")
      .required("Required"),

      title: Yup.string()
      .min(2, "Too Short!")
      .max(50, "Too Long!")
      .required("Required"),
  });

  

  const formik = useFormik({
    initialValues: initialdata,
    enableReinitialize:true,
    validationSchema: postSchema,
    onSubmit: async (values) => {
      console.log("submit", values);
      try {
        const currentDate = new Date().toDateString();
        const obj={...values,date:currentDate}
        const res = await updatePost(obj);

        if (res.status == 201) {
          toast.success("post update sucessfully");
          router.push("/")
        }
      } catch (error) {
        console.log(error);
        toast.error("something went wrong");
      }
    },
  });
  
  const { handleChange, errors, handleSubmit, touched } = formik;

  const updatePost = async (values) => {
    try {
      const userdata=localStorage.getItem("user");
      const userExist=JSON.parse(userdata);
      const obj={...values,...userExist}
      

      const res = await axios.put(`http://localhost:3000/api/update?id=${params.id}`, obj);
      return res;
    } catch (error) {
      console.log(error);
      return error;
    }
  };
  
  return (
    <div className="mt-20 w-[70%] mx-auto p-3  ">
      <Suspense fallback={<p>Fetching...</p>}>

      <Paper className="flex p-4  space-x-10 ">
        <div className="w-[50px] h-[50px] bg-orange-500 text-2xl  rounded-full flex items-center  justify-center  font-bold text-white">{formik?.values?.user?.charAt(0).toUpperCase()}</div>
        <div className="flex text-semibold text-xl  items-center ">{formik.values.user}</div>
      </Paper>

      <Paper className="p-3  mt-4 ">

       <div className="flex justify-end ">
        <DeleteIcon onClick={deletepost} />
       </div>
      <form onSubmit={handleSubmit} className=" mx-10   ">
        <div className="mt-5 p-2  space-y-2    ">
          <div>
            <p>
              <span className="text-semibold">Title</span>{" "}
              <span className="text-gray-400 "></span>
            </p>

            <input
              onChange={handleChange}
              style={{ outlineColor:'orange' }}
              value={formik.values.title}
              name="title"
              type="text"
              className="w-full border-gray-400 p-2 border mt-2  "
            ></input>
            {errors.title && touched.title && (
              <p className="text-xs text-red-500 mt-1 ">{errors.title}</p>
            )}
          </div>
          <p>Your Ai prompt</p>

          <textarea
            name="post"
            value={formik.values.post}
            onChange={handleChange}
            placeholder="write your post here"
            className="bg-white border p-2 outline-none  border-gray-300"
            rows={5}
            cols={107}
          ></textarea>

          {errors.post && touched.post && (
            <p className="text-xs text-red-500  ">{errors.post}</p>
          )}
        </div>

        <div className="p-2 ">
          <p>
            <span className="text-semibold">Tag</span>{" "}
            <span className="text-gray-400 ">(idea,product,development) </span>
          </p>

          <input
           style={{ outlineColor:'orange' }}
            onChange={handleChange}
            value={formik.values.tag}
            name="tag"
            type="text"
            className="w-full border-gray-400 p-2 border mt-2  "
          ></input>
          {errors.tag && touched.tag && (
            <p className="text-xs text-red-500 mt-1 ">{errors.tag}</p>
          )}

          <div className="flex justify-end space-x-3  mt-5 ">
            <button 
            onClick={()=>router.push("/")}
              type="button"
              className="border p-1 border-black  rounded-sm  hover:bg-black hover:text-white  w-[100px] "
            >
              Cancel
            </button>

            <button
              //   onClick={createPost}
              className="border p-1 border-black  rounded-sm hover:bg-black hover:text-white  w-[100px] "
            >
              Update
            </button>
          </div>
        </div>
      </form>

</Paper>

</Suspense>


    </div>
  );
}


