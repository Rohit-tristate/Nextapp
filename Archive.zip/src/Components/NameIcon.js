export default function NameIcon(props){
    
    return(
        <div>
            <div className="w-[30px] bg-orange-500 rounded-full flex justify-center items-center p-1 text-white font-blod   h-[30px] ">
                {props.name}
            </div>
        </div>

    )
}