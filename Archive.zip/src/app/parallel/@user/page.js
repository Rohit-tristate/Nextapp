import { Paper } from "@mui/material";
import Link from "next/link";

  export default function page(){
    return(
        <Paper className="h-full" >
            <h1>User</h1>
            <Link href="/parallel/post">Post</Link>
            </Paper>
    )
  }