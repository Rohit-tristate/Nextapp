import { Paper } from "@mui/material";

  export default function page(){

    
    return(
        <Paper className="h-full">
            <h1>Admin</h1>


        </Paper>
    )
  }