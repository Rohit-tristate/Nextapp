'use client'

export default function error(error) {

  return(<div>Error</div>);
}
