export default function page(){

    return (
        <h1>Post</h1>

    )

}
   
