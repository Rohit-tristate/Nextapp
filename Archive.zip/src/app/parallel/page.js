  export default function page(){

    return(
        <div className="mt-20">
            <h1>Parallel Routing</h1>
        </div>
    )

  }