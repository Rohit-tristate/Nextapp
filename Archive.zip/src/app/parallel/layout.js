import { Paper } from "@mui/material";
import Link from "next/link";

export default function layout({ children, admin, user }) {
  return (
    <Paper className="">
      <div className="grid grid-cols-3 gap-3 h-[50vh] ">
        <Paper className="col-span-3 ">{children}</Paper>
        <Paper className="h-full">
          <div>{admin}</div>
        </Paper>
        <Paper className="col-span-2 h-full ">
          <div>{user}</div>
        </Paper>
      </div>
    </Paper>
  );
}
