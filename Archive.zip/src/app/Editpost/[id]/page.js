// "use client"
import Updatepost from "@/Components/Createpost";
import { Paper } from "@mui/material";
import axios from "axios";

export default async function Edit({ params }) {
  console.log("param", params);
  const obj = await getdata(params.id);
  console.log("data", obj);
  return <div> <Updatepost arr={obj}/> </div>;
}

export async function getdata(id) {
  try {
    const res = await axios.post(`http://localhost:3000/api/Getpost/post`, {
      id,
    });

    const obj = {
      post: res.data.message.post,
      title: res.data.message.title,
      user: res.data.message.user,
      tag: res.data.message.tag,
    };
    return obj;
  } catch (error) {
    console.log(error);
  }
}
