import postdata from "@/models/PostSchema";
import { connectDb } from "@/utili/Db";
import { NextResponse } from "next/server";


export const POST=async(req,res)=>{
   
    try{

       await connectDb();
        const data=await req.json();
       

         const post=new postdata({
            post:data.post,
            tag:data.tag,
            user:data.user,
            title:data.title,
            date:data.date
       })

       const save= await post.save();

        return NextResponse.json({message:"successfully"},{status:201})


    }catch(error){
        console.log(error)
       
        return NextResponse.json({message:error},{status:400})
    }
}