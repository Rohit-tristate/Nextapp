import postdata from "@/models/PostSchema";
import { connectDb } from "@/utili/Db";
import { NextResponse } from "next/server";


export const GET=async(req,res)=>{
   
    try{

       await connectDb();
        
       const data=await postdata.find();


        return NextResponse.json({message:data},{status:201})


    }catch(error){
        console.log(error)
       
        return NextResponse.json({message:error},{status:400})
    }
}
