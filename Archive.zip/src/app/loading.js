import SimpleBackdrop from "@/Components/Loading";

  export default function loading(){
    return <SimpleBackdrop/>
  }