
"use client"
import { toast } from "react-toastify";


export default function Error(){
  return toast.error("something went Wrong")

}